#!/usr/bin/env bash
# docs/deploy.sh - szybkie wdrożenie podserwera na Ubuntu
# Użycie: ./deploy.sh files.twojadomena.pl
set -euo pipefail

DOMAIN="${1:-files.twojadomena.pl}"
APP_DIR="/opt/podserver"

sudo mkdir -p "$APP_DIR"
sudo chown "$USER":"$USER" "$APP_DIR"

# kopiuj pliki
cp "$(dirname "$0")/../podserver/app.py" "$APP_DIR/app.py"
mkdir -p "$APP_DIR/files"

# python env
sudo apt update
sudo apt install -y python3 python3-venv python3-pip nginx certbot python3-certbot-nginx
python3 -m venv "$APP_DIR/venv"
source "$APP_DIR/venv/bin/activate"
pip install flask werkzeug

# systemd
sudo cp "$(dirname "$0")/../systemd/podserver.service" /etc/systemd/system/podserver.service
sudo systemctl daemon-reload
sudo systemctl enable podserver
sudo systemctl restart podserver

# nginx
sudo cp "$(dirname "$0")/../nginx/files.conf" /etc/nginx/sites-available/files
sudo ln -sf /etc/nginx/sites-available/files /etc/nginx/sites-enabled/files
sudo nginx -t && sudo systemctl reload nginx

# certbot
sudo certbot --nginx -d "$DOMAIN" --redirect --agree-tos -m admin@"$DOMAIN" -n

echo "DONE. Podserwer dostępny pod https://$DOMAIN"
