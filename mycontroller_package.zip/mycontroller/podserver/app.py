# podserver/app.py
from flask import Flask, request, jsonify, send_from_directory
import os, time, uuid
from werkzeug.utils import secure_filename
from threading import Lock

# ====== KONFIGURACJA ======
ADMIN_TOKEN = "CHANGE_THIS_ADMIN_TOKEN"   # USTAW SILNE HASŁO
FILES_DIR = os.path.join(os.getcwd(), "files")
MAX_FILE_SIZE_MB = 4096
TEMP_TOKEN_TTL = 120   # ważność tokenu tymczasowego (s)
PORT = 6000
# ==========================

os.makedirs(FILES_DIR, exist_ok=True)
LOG_FILE = os.path.join(os.getcwd(), "server.log")

app = Flask(__name__)
_temp_tokens = {}  # token -> {type:'download'|'upload', filename:..., expires:int}
_lock = Lock()

def now_ts(): return int(time.time())

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    print(msg)

def check_admin(req):
    token = req.headers.get("X-Token")
    return token == ADMIN_TOKEN

def cleanup_tokens():
    with _lock:
        expired = [t for t,m in _temp_tokens.items() if m['expires'] <= now_ts()]
        for t in expired:
            del _temp_tokens[t]

@app.route("/prepare_download", methods=["POST"])
def prepare_download():
    if not check_admin(request): return jsonify({"error":"unauthorized"}), 401
    data = request.json or {}
    filename = data.get("filename")
    if not filename: return jsonify({"error":"filename required"}), 400
    filename = secure_filename(filename)
    path = os.path.join(FILES_DIR, filename)
    if not os.path.exists(path): return jsonify({"error":"not found"}), 404

    token = uuid.uuid4().hex
    expires = now_ts() + TEMP_TOKEN_TTL
    with _lock:
        _temp_tokens[token] = {"type":"download", "filename": filename, "expires": expires}
    host = request.host
    url = f"http://{host}/download/{filename}?token={token}"
    log(f"Prepared download token for {filename} => {token} (ttl={TEMP_TOKEN_TTL})")
    return jsonify({"download_url": url, "expires_in": TEMP_TOKEN_TTL})

@app.route("/prepare_upload", methods=["POST"])
def prepare_upload():
    if not check_admin(request): return jsonify({"error":"unauthorized"}), 401
    data = request.json or {}
    filename = data.get("filename")
    if filename: filename = secure_filename(filename)
    token = uuid.uuid4().hex
    expires = now_ts() + TEMP_TOKEN_TTL
    with _lock:
        _temp_tokens[token] = {"type":"upload", "filename": filename, "expires": expires}
    host = request.host
    url = f"http://{host}/upload?token={token}"
    log(f"Prepared upload token target={filename} => {token} (ttl={TEMP_TOKEN_TTL})")
    return jsonify({"upload_url": url, "expires_in": TEMP_TOKEN_TTL})

@app.route("/upload", methods=["POST"])
def upload():
    cleanup_tokens()
    token = request.args.get("token", None)
    if not token and not check_admin(request):
        return jsonify({"error":"unauthorized"}), 401
    meta = None
    if token:
        with _lock:
            meta = _temp_tokens.get(token)
            if not meta or meta["type"] != "upload" or meta["expires"] <= now_ts():
                return jsonify({"error":"invalid token"}), 401
            del _temp_tokens[token]

    if "file" not in request.files:
        return jsonify({"error":"no file part"}), 400
    f = request.files["file"]
    fname = secure_filename(f.filename) if f.filename else None
    target_name = meta.get("filename") if meta else None
    filename = target_name or fname
    if not filename:
        return jsonify({"error":"filename missing"}), 400

    filepath = os.path.join(FILES_DIR, filename)
    f.save(filepath)
    size_mb = os.path.getsize(filepath)/(1024*1024)
    if size_mb > MAX_FILE_SIZE_MB:
        os.remove(filepath)
        return jsonify({"error":"file too large"}), 400
    log(f"Uploaded {filename} ({size_mb:.2f} MB) via {'token' if token else 'admin'}")
    return jsonify({"status":"ok", "filename": filename})

@app.route("/download/<path:filename>", methods=["GET"])
def download(filename):
    cleanup_tokens()
    token = request.args.get("token", None)
    if not token and not check_admin(request):
        return jsonify({"error":"unauthorized"}), 401
    if token:
        with _lock:
            meta = _temp_tokens.get(token)
            if not meta or meta["type"] != "download" or meta["expires"] <= now_ts():
                return jsonify({"error":"invalid token"}), 401
            if meta["filename"] != filename:
                return jsonify({"error":"token filename mismatch"}), 401
            del _temp_tokens[token]
    filename = secure_filename(filename)
    path = os.path.join(FILES_DIR, filename)
    if not os.path.exists(path): return jsonify({"error":"not found"}), 404
    log(f"Download {filename} via {'token' if token else 'admin'}")
    return send_from_directory(FILES_DIR, filename, as_attachment=True)

@app.route("/list", methods=["GET"])
def list_files():
    if not check_admin(request): return jsonify({"error":"unauthorized"}), 401
    return jsonify({"files": os.listdir(FILES_DIR)})

@app.route("/delete/<path:filename>", methods=["DELETE"])
def delete_file(filename):
    if not check_admin(request): return jsonify({"error":"unauthorized"}), 401
    filename = secure_filename(filename)
    p = os.path.join(FILES_DIR, filename)
    if os.path.exists(p):
        os.remove(p); log(f"Deleted {filename}")
        return jsonify({"status":"deleted"})
    return jsonify({"error":"not found"}), 404

@app.route("/active_temp_tokens", methods=["GET"])
def active_temp_tokens():
    if not check_admin(request): return jsonify({"error":"unauthorized"}), 401
    cleanup_tokens()
    with _lock:
        return jsonify({t:{"type":m['type'],"filename":m['filename'],"expires_in":m['expires']-now_ts()} for t,m in _temp_tokens.items()})

if __name__ == "__main__":
    log(f"Starting podserver on port {PORT}")
    app.run(host="0.0.0.0", port=PORT)
