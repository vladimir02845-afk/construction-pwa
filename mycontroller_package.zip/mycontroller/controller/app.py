# controller/app.py
from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import requests, os, time

# ====== KONFIGURACJA ======
PODSERVER_BASE = "http://ADRES_VPS:6000"         # <-- publiczny adres/port VPS (zmień! lub https://files.twojadomena.pl)
PODSERVER_ADMIN_TOKEN = "CHANGE_THIS_ADMIN_TOKEN" # <-- identyczny jak na VPS
UI_DIR = os.path.join(os.path.dirname(__file__), "..", "web_ui")
PORT = 5000
# ==========================

app = FastAPI()
app.mount("/ui", StaticFiles(directory=UI_DIR), name="ui")
LOG = []

def admin_headers():
    return {"X-Token": PODSERVER_ADMIN_TOKEN}

@app.post("/api/list")
def api_list():
    try:
        r = requests.get(f"{PODSERVER_BASE}/list", headers=admin_headers(), timeout=15)
        return JSONResponse(content=r.json(), status_code=r.status_code)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))

@app.post("/api/prepare_download")
def api_prepare_download(filename: str = Form(...)):
    try:
        r = requests.post(f"{PODSERVER_BASE}/prepare_download",
                          json={"filename": filename}, headers=admin_headers(), timeout=15)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
    data = r.json()
    LOG.append({"time": time.time(), "action": "prepare_download", "filename": filename, "resp": data})
    return JSONResponse(content=data, status_code=r.status_code)

@app.post("/api/prepare_upload")
def api_prepare_upload(filename: str = Form(None)):
    try:
        r = requests.post(f"{PODSERVER_BASE}/prepare_upload",
                          json={"filename": filename or None}, headers=admin_headers(), timeout=15)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
    data = r.json()
    LOG.append({"time": time.time(), "action": "prepare_upload", "filename": filename, "resp": data})
    return JSONResponse(content=data, status_code=r.status_code)

@app.post("/api/delete")
def api_delete(filename: str = Form(...)):
    try:
        r = requests.delete(f"{PODSERVER_BASE}/delete/{filename}", headers=admin_headers(), timeout=15)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
    data = r.json()
    LOG.append({"time": time.time(), "action": "delete", "filename": filename, "resp": data})
    return JSONResponse(content=data, status_code=r.status_code)

@app.get("/api/logs")
def api_logs():
    return {"logs": LOG}

# ===== NEW: Upload przez controller (proxy) =====
@app.post("/api/upload_direct")
async def api_upload_direct(file: UploadFile = File(...), target_name: str = Form(None)):
    # 1) poproś podserwer o tymczasowy upload_url
    try:
        r = requests.post(f"{PODSERVER_BASE}/prepare_upload",
                          json={"filename": target_name or None},
                          headers=admin_headers(), timeout=30)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
    if r.status_code != 200:
        return JSONResponse(content=r.json(), status_code=r.status_code)
    upload_info = r.json()
    upload_url = upload_info.get("upload_url")
    if not upload_url:
        raise HTTPException(status_code=502, detail="Brak upload_url z podserwera")

    # 2) prześlij do podserwera jako multipart
    files = {"file": (target_name or file.filename, file.file)}
    try:
        r2 = requests.post(upload_url, files=files, timeout=3600)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
    data = r2.json() if r2.content else {"status": "unknown"}
    LOG.append({"time": time.time(), "action": "upload_direct", "target_name": target_name or file.filename, "resp": data})
    return JSONResponse(content=data, status_code=r2.status_code)

@app.get("/")
def root():
    return HTMLResponse('<html><body><script>location.href="/ui/";</script></body></html>')
